This is a web app developed with Python Flask and SQLite for hotel room reservations.

- Home page
- Reservation form
- Confirmation screen
- Reservation listing
