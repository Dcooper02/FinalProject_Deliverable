from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from datetime import datetime

app = Flask(__name__)
DB_FILE = 'hotel.db'

def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS reservations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                check_in TEXT NOT NULL,
                check_out TEXT NOT NULL,
                room_type TEXT NOT NULL
            )
        ''')
        conn.commit()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/reserve', methods=['GET', 'POST'])
def reserve():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        check_in = request.form['check_in']
        check_out = request.form['check_out']
        room_type = request.form['room_type']

        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute("INSERT INTO reservations (name, email, check_in, check_out, room_type) VALUES (?, ?, ?, ?, ?)",
                      (name, email, check_in, check_out, room_type))
            conn.commit()

        return render_template('confirm.html', name=name, check_in=check_in, check_out=check_out, room_type=room_type)
    
    return render_template('reserve.html')

@app.route('/reservations')
def reservations():
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM reservations")
        all_reservations = c.fetchall()
    return render_template('reservations.html', reservations=all_reservations)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
